﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace ST.Hotel.Models
{
    public class ReservationViewModel
    {

        public ReservationForm Reservation { get; set; }
        public IEnumerable<SelectListItem>Rooms { get; set; }

    }
}
