﻿using Microsoft.AspNetCore.Mvc;
using ST.Hotel.Models;
using ST.Hotel.Repositories;

namespace ST.Hotel.Controllers
{
    public class ReservationController : Controller
    {
        public readonly IReservationRepository _reservationRepository;

        public ReservationController(IReservationRepository reservationRepository)
        {
            _reservationRepository= reservationRepository;
        }



        public IActionResult Index()
        {
            var reservations =_reservationRepository.ReadReservation();
            return View(reservations);
        }

        public IActionResult Add()
        {
            ReservationViewModel model =new ReservationViewModel();
            model.Rooms= _reservationRepository.ReadRooms();
            return View(model);
        }


        [HttpPost]
        public IActionResult Add(ReservationViewModel model)
        {
            _reservationRepository.AddReservation(model.Reservation);
            return RedirectToAction("Index");
        }




    }
}
