﻿using ST.Hotel.Repositories;

namespace ST.Hotel.Extensions
{
    public static class HotelExtensions
    {
        public static IServiceCollection AddHotelServices(this IServiceCollection serviceCollection)
        {//3
            //serviceCollection.AddTransient<IReservationRepository, ReservationRepositoryBase>();
            //serviceCollection.AddDbContext<HotelDbContext, HotelDbContext>();
            //return serviceCollection;

            //4
            serviceCollection.AddTransient<IReservationRepository, ReservationRepository>();
            serviceCollection.AddDbContext<HotelDbContext, HotelDbContext>();
            return serviceCollection;

        }
    }
}
