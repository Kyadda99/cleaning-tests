﻿using Microsoft.AspNetCore.Mvc.Rendering;
using ST.Hotel.Entities;
using ST.Hotel.Models;

namespace ST.Hotel.Repositories
{
    public interface IReservationRepository
    {
        void AddReservation(ReservationForm reservation);
        
        List<ReservationList> ReadReservation();
        List<SelectListItem> ReadRooms();



    }
}
