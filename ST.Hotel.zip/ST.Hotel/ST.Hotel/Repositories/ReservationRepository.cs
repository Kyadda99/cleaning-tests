﻿using Microsoft.AspNetCore.Mvc.Rendering;
using ST.Hotel.Entities;
using ST.Hotel.Models;

namespace ST.Hotel.Repositories
{   // 4
    public class ReservationRepository : IReservationRepository
    {

        private readonly HotelDbContext _context;

        public ReservationRepository(HotelDbContext context)
        {
            _context = context;
        }

        public void AddReservation(ReservationForm reservation)
        {
            var reservationEntity = new Reservation()
            {
                Date = reservation.Date,
                Email = reservation.Email,
                Id = reservation.Id,
                PhoneNumber = reservation.PhoneNumber,
                RoomId = reservation.RoomId,
            };
            _context.Reservations.Add(reservationEntity);
            _context.SaveChanges();
        }

        public List<ReservationList> ReadReservation()
        {
            return _context.Reservations.Select(r=> new ReservationList()
            {
                Date = r.Date,
                Email = r.Email,
                Id = r.Id,
                PhoneNumber = r.PhoneNumber,
               
            }).ToList();
        }

        public List<SelectListItem> ReadRooms()
        {
            return _context.Rooms.Select(r => new SelectListItem()
            {
                Text = r.Name,
                Value = r.Id.ToString(),
            }).ToList();
        }
    }
}
