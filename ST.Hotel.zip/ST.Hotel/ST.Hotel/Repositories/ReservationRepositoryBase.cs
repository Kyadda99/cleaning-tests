﻿using Microsoft.AspNetCore.Mvc.Rendering;
using ST.Hotel.Entities;
using ST.Hotel.Models;

namespace ST.Hotel.Repositories
{
    public class ReservationRepositoryBase : IReservationRepository
    {
        private static List<ReservationForm> reservations = new List<ReservationForm>()
        {
            new ReservationForm() {
            Date = DateTime.Now,
            Email = "test@gmail.com",
            Id = 1,
            PhoneNumber= "1234567890",
            RoomId= 1,
            }
        };

        public void AddReservation(ReservationForm reservation)
        {
            reservations.Add(reservation);       
        }

        public List<ReservationList> ReadReservation()
        {
            return reservations.Select(r => new ReservationList()
            {
                PhoneNumber = r.PhoneNumber,
                Email = r.Email,
                Id = r.Id,
                Date = DateTime.Now,
                Room = r.RoomId.ToString(),
            }).ToList();
        }
        public List<SelectListItem> ReadRooms()
        {
            return new List<SelectListItem>()
            {
                new SelectListItem() {Text = "Pokoj 1",Value = "1"}
            };    
        }
    }
}
